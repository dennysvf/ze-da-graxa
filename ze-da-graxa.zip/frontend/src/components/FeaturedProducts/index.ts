export { FeaturedProducts } from './FeaturedProducts';
