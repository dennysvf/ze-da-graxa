export { ProductDetails } from './ProductDetails'
